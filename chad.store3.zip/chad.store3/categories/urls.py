from django.urls import path 
from categories.views import CategoryDetailView, CategoryListView, CategoryImageListView